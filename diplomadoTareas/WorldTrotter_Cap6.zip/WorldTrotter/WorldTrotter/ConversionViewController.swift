//
//  ConversionViewController.swift
//  WorldTrotter
//
//  Created by Edgar on 14/05/18.
//  Copyright © 2018 Edgar. All rights reserved.
//

import UIKit
class ConversionViewController: UIViewController {

    @IBOutlet var celsiusLabel: UILabel!
    @IBAction func fahrenheitFieldEditingChanged(_ textField: UITextField) {
        celsiusLabel.text = textField.text
    }

}
