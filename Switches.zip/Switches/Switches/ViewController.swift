//
//  ViewController.swift
//  Switches
//
//  Created by d182_Adrian_R on 09/03/18.
//  Copyright © 2018 DiplomadoiOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindToRed(unwindSegue: UIStoryboardSegue){
        
    }//unwindToRed

    @IBAction func switchActivated(_ sender: UISwitch) {
        if sender.isOn {
            print("The switch is on")
        }//if
        else{
            print("The switch is off")
        }//else
    }
    
    @IBAction func sliderAction(_ sender: UISlider) {
        print(sender.value)
    }//sliderAction
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let text = miTextField.text {
        segue.destination.navigationItem.title = text
        }
    }
    

    @IBOutlet weak var miTextField: UITextField!
    
    
}

