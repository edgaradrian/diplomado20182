//
//  MainTabViewController.swift
//  automotion
//
//  Created by d182_Adrian_R on 16/03/18.
//  Copyright © 2018 DiplomadoiOS. All rights reserved.
//

import UIKit

class MainTabViewController: UITabBarController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        guard let unwrappedItems = self.tabBar.items else { return }
        
        for item in unwrappedItems{
            notifica(item)
        }
    }

    func notifica(_ item: UITabBarItem){
        for i in 1 ... 10 {
         item.badgeValue = String(i)
        }
        //deshabilita(item)
    }
    
    func deshabilita(_ item: UITabBarItem) {
       item.isEnabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
