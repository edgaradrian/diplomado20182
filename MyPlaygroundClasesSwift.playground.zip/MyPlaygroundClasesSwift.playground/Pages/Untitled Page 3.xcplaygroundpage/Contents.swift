//: [Previous](@previous)

import UIKit

class Alumno{
    var numCuenta: String
    var edad: Int{
        willSet{
            print("El nuevo valor: \(newValue)")
        }
        didSet{
            print("Valor anterior: \(oldValue)")
        }
    }
    
    init(numCuenta: String){
        self.numCuenta = numCuenta
    }
    
    func estudiar(materia: String) {
        print("Se encuentra estudiando: \(materia)")
    }
    
}

class Ingenieria: Alumno{
    override func estudiar(materia: String) {
        print("Estudia la mejor carrera: \(materia)")
    }
}

class Contaduria: Alumno{
    override func estudiar(materia: String) {
        print("Estudia una materia fácil \(materia)")
    }
}

var ingeniero = Ingenieria(numCuenta: "0001")
var contador = Contaduria(numCuenta: "0002")

print(ingeniero.estudiar(materia: "Ingenieria"))
print(contador.estudiar(materia: "Contaduria"))




//: [Next](@next)
