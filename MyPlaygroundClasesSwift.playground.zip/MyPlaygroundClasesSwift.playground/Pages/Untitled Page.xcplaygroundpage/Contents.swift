//: Playground - noun: a place where people can play

import UIKit

class Alumno{
    var numCuenta: String
    
    init(numCuenta: String){
        self.numCuenta = numCuenta
    }
    
}

class Ingenieria: Alumno{
    
}

struct Profesor{
    var numEmpleo: String
}


var marduk = Profesor(numEmpleo: "000000")
var parrita = Alumno(numCuenta: "99999999")

var adrian = parrita
adrian.numCuenta = "88888888"

parrita.numCuenta 
