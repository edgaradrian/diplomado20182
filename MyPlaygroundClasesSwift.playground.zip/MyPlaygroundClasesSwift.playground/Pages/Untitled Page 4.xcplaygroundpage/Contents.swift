//: [Previous](@previous)

import Foundation

class Empleado{
    var sueldo: Double{
        willSet{
            if newValue <= 0{
                print("No es un valor valido")
            }
        }
        didSet{
            
        }
    }
    var descuento: Double{
        willSet{
            if newValue >= sueldo{
                print("No es un sueldo valido")
            }
        }
        didSet{
            
        }
    }
    
    init(sueldo: Double, descuento: Double) {
        self.sueldo = sueldo
        self.descuento = descuento
    }
    
}

var miEmpleado = Empleado(sueldo: 10000, descuento: 1000)

miEmpleado.descuento=10000
miEmpleado.sueldo = -1


//: [Next](@next)
