//
//  ViewController.swift
//  EjercicioTextFieldCloseKeyboard
//
//  Created by d182_Adrian_R on 09/03/18.
//  Copyright © 2018 DiplomadoiOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var miTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        miTextField.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func ocultaTeclado(_ sender: UIButton) {
        miTextField.resignFirstResponder()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.resignFirstResponder()
    }
    
}

