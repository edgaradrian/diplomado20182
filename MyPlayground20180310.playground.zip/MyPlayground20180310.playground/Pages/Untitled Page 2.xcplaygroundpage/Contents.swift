//: [Previous](@previous)

import Foundation

enum EstadoDocumento: Int {
    case Recibido = 0, Validado, EnProceso, Publicado
}

let valorEstado = EstadoDocumento.Validado.rawValue
let estado = EstadoDocumento(rawValue: 2)

enum ResultadoWebService {
    case Exito(String)
    case Error(Int)
}

func llamadaWS() -> ResultadoWebService {
    if false {
        return ResultadoWebService.Exito("Mi contenido")
    } else {
        return ResultadoWebService.Error(502)
    }
}


let resultado: ResultadoWebService = llamadaWS()
switch resultado {
case let .Exito(contenido):
    print(contenido)
case let .Error(codigo):
    print("El codigo de error es \(codigo)")
}

