//: Playground - noun: a place where people can play

import Cocoa

let main = DispatchQueue.main
let background = DispatchQueue.global()

func doSyncWork() {
    background.async {
        for _ in 1...3 {
            print("Light")
        }
    }

    for _ in 1...3 {
        print("Heavy")
    }

}

doSyncWork()

let asianWorker = DispatchQueue(label: "construction_worker_1")

let brownWorker = DispatchQueue(label: "construction_worker_2")

func doLightWord(){
    
    asianWorker.async {
        for _ in 1...10 {
            print("👷🏻‍♂️")
        }
    }
    
    brownWorker.async {
        for _ in 1...10 {
            print("👷🏽‍♂️")
        }
    }
    
}

doLightWord()

////////////////

let whiteWorker = DispatchQueue(label: "construction:worker_3", qos: .background)//lower importance
let blackWorker = DispatchQueue(label: "construction:worker_4", qos: .userInitiated)//higher importance

func doLightWorks(){
    whiteWorker.async {
        for _ in 1...10 {
            print("👷🏻‍♂️")
        }
    }
    
    blackWorker.async {
        for _ in 1...10 {
            print("👷🏾‍♂️")
        }
    }
    
}


doLightWorks()
